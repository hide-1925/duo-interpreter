/* Fullscreen support stays in the isolated extension world. No player methods are replaced. */
(() => {
  'use strict';
  globalThis.DuoOverlayFullscreen = function(root, canvas, onResize) {
    let shell=null,disposed=false,lastSent=null,serial=0,error='';
    const element=()=>document.fullscreenElement||document.webkitFullscreenElement||null;
    const visible=()=>!root.classList.contains('duo-hidden');
    function closeShell(){
      if(!shell)return;
      try{if(shell.matches(':popover-open'))shell.hidePopover();}catch(_){}
      shell.remove();shell=null;
    }
    function mount(){
      const fs=element();
      if(!fs||!visible()){
        for(const node of [canvas,root])if(node.parentNode!==document.documentElement)document.documentElement.appendChild(node);
        closeShell();return;
      }
      if(typeof HTMLElement.prototype.showPopover==='function'){
        if(!shell){shell=document.createElement('div');shell.id='duo-fullscreen-layer';shell.setAttribute('popover','manual');}
        // Top-layer paint order alone does not remove Chromium fullscreen
        // inertness. Keep the controls inside the active fullscreen subtree.
        if(shell.parentNode!==fs){
          try{if(shell.matches(':popover-open'))shell.hidePopover();}catch(_){}
          fs.appendChild(shell);
        }
        for(const node of [canvas,root])if(node.parentNode!==shell)shell.appendChild(node);
        try{if(!shell.matches(':popover-open'))shell.showPopover();error='';return;}catch(e){error=String(e.message||e);}
      }
      // Older engines can render children of a player container, but not of video/iframe.
      const parent=/^(VIDEO|IFRAME|EMBED|OBJECT)$/.test(fs.tagName)?document.documentElement:fs;
      for(const node of [canvas,root])if(node.parentNode!==parent)parent.appendChild(node);
      closeShell();
      if(parent===document.documentElement&&fs!==parent)error='このブラウザでは動画要素への全画面字幕を表示できません。ブラウザを更新してください。';
    }
    function notify(){
      const active=!!element();
      if(active===lastSent)return;
      lastSent=active;const revision=++serial;
      chrome.runtime.sendMessage({type:'DUO_FULLSCREEN_CHANGED',active}).then(r=>{
        if(disposed||revision!==serial)return;
        if(!r?.ok){error=r?.error||'全画面の切り替えを確認できません';lastSent=null;}
      }).catch(e=>{if(!disposed&&revision===serial){error=String(e.message||e);lastSent=null;}});
    }
    function sync(){if(disposed)return;mount();onResize();notify();}
    function changed(){sync();}
    function dispose(){disposed=true;document.removeEventListener('fullscreenchange',changed);document.removeEventListener('webkitfullscreenchange',changed);}
    document.addEventListener('fullscreenchange',changed);
    document.addEventListener('webkitfullscreenchange',changed);
    addEventListener('pagehide',event=>{if(!event.persisted)dispose();});
    return {sync,snapshot(){return {active:!!element(),element:element()?.tagName||null,
      layer:shell?.matches(':popover-open')?'top-layer':element()?'container':'page',visible:visible(),error};}};
  };
})();
