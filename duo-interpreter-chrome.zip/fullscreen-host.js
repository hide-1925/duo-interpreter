'use strict';
// A captured tab can enter DOM fullscreen without changing the browser window.
// Own only the window transitions made here; never undo an existing F11 fullscreen.
const FULLSCREEN_OWNER_KEY='duoFullscreenOwner';
let fullscreenQueue=Promise.resolve();
function queueFullscreen(task){const next=fullscreenQueue.then(task);fullscreenQueue=next.catch(()=>{});return next;}
async function releaseDuoFullscreen(tabId){
  const owner=(await chrome.storage.session.get(FULLSCREEN_OWNER_KEY))[FULLSCREEN_OWNER_KEY];
  if(!owner||tabId!=null&&owner.tabId!==tabId)return;
  await chrome.storage.session.remove(FULLSCREEN_OWNER_KEY);
  try{
    const win=await chrome.windows.get(owner.windowId);
    if(win.state==='fullscreen')await chrome.windows.update(owner.windowId,{state:owner.state});
  }catch(_){}
}
function syncDuoFullscreen(message,sender){return queueFullscreen(async()=>{
  const state=await getState();
  if(sender.tab?.id!==state.targetTabId||sender.frameId!==0)throw Error('字幕対象タブ以外からの全画面操作です');
  const tab=await chrome.tabs.get(state.targetTabId);
  const pong=await chrome.tabs.sendMessage(tab.id,{type:'DUO_PING'},{frameId:0});
  // Ignore stale enter/exit messages after rapid toggles or navigation.
  if(!pong?.fullscreen||pong.fullscreen.active!==!!message.active)return {ok:true,ignored:true};
  if(!message.active){await releaseDuoFullscreen(tab.id);return {ok:true};}
  if(!state.overlayEnabled||!tab.active)return {ok:true,ignored:true};
  const win=await chrome.windows.get(tab.windowId);
  if(win.state==='fullscreen')return {ok:true,existing:true};
  await releaseDuoFullscreen();
  const owner={tabId:tab.id,windowId:tab.windowId,state:win.state==='maximized'?'maximized':'normal'};
  await chrome.storage.session.set({[FULLSCREEN_OWNER_KEY]:owner});
  try{await chrome.windows.update(tab.windowId,{state:'fullscreen'});}
  catch(e){await chrome.storage.session.remove(FULLSCREEN_OWNER_KEY);throw e;}
  return {ok:true,expanded:true};
});}
chrome.tabs.onRemoved.addListener(tabId=>{queueFullscreen(()=>releaseDuoFullscreen(tabId));});
chrome.tabs.onUpdated.addListener((tabId,change)=>{if(change.status==='loading')queueFullscreen(()=>releaseDuoFullscreen(tabId));});
chrome.tabs.onActivated.addListener(info=>{queueFullscreen(async()=>{
  const owner=(await chrome.storage.session.get(FULLSCREEN_OWNER_KEY))[FULLSCREEN_OWNER_KEY];
  if(owner&&info.windowId===owner.windowId&&info.tabId!==owner.tabId)await releaseDuoFullscreen(owner.tabId);
});});
