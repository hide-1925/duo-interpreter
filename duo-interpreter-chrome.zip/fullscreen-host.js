'use strict';
// A captured tab can enter DOM fullscreen without changing the browser window.
// Native fullscreen is asynchronous: do not race it with an extension window update.
// Own only the window transitions made here; never undo an existing F11 fullscreen.
const FULLSCREEN_OWNER_KEY='duoFullscreenOwner';
const FULLSCREEN_SETTLE_MS=500;
let fullscreenQueue=Promise.resolve();
function queueFullscreen(task){const next=fullscreenQueue.then(task);fullscreenQueue=next.catch(()=>{});return next;}
async function releaseDuoFullscreen(tabId){
  const owner=(await chrome.storage.session.get(FULLSCREEN_OWNER_KEY))[FULLSCREEN_OWNER_KEY];
  if(!owner||tabId!=null&&owner.tabId!==tabId)return;
  await chrome.storage.session.remove(FULLSCREEN_OWNER_KEY);
  try{
    const win=await chrome.windows.get(owner.windowId);
    if(win.state==='fullscreen')await chrome.windows.update(owner.windowId,{state:owner.state});
  }catch(_){}
}
function syncDuoFullscreen(message,sender){return queueFullscreen(async()=>{
  const state=await validateOverlayFrameSender(sender);
  const tab=await chrome.tabs.get(state.targetTabId);
  const pong=await chrome.tabs.sendMessage(tab.id,{type:'DUO_PING'},sender.documentId?{frameId:sender.frameId,documentId:sender.documentId}:{frameId:sender.frameId});
  // Ignore stale enter/exit messages after rapid toggles or navigation.
  if(!pong?.fullscreen||pong.fullscreen.active!==!!message.active)return {ok:true,ignored:true};
  const history=[...(state.duoFullscreenHistory||[]),{at:Date.now(),frameId:sender.frameId,active:!!message.active,element:pong.fullscreen.element||null,layer:pong.fullscreen.layer||null,visible:!!pong.fullscreen.visible,error:pong.fullscreen.error||''}].slice(-40);
  await setState({duoFullscreenHistory:history});
  // A recording can be paused when fullscreen starts: replay current captions
  // immediately rather than waiting for the next STT update.
  if(message.active&&state.htmlTabId)await deliverHtml(await getState());
  if(!message.active){
    const frames=await readOverlayFrameStatus(tab.id);
    if(!frames.some(f=>f.fullscreen?.active))await releaseDuoFullscreen(tab.id);
    return {ok:true};
  }
  if(!state.overlayEnabled||!tab.active)return {ok:true,ignored:true};
  let win=await chrome.windows.get(tab.windowId);
  if(win.state==='fullscreen')return {ok:true,existing:true};
  // fullscreenchange can arrive before Chrome reports the native window transition.
  // An immediate windows.update can introduce a second viewport transition while
  // the player is sizing its video. Only help if native fullscreen still needs it.
  await new Promise(resolve=>setTimeout(resolve,FULLSCREEN_SETTLE_MS));
  const latestState=await validateOverlayFrameSender(sender);
  const latestTab=await chrome.tabs.get(tab.id);
  const latestPong=await chrome.tabs.sendMessage(tab.id,{type:'DUO_PING'},sender.documentId?{frameId:sender.frameId,documentId:sender.documentId}:{frameId:sender.frameId});
  if(!latestState.overlayEnabled||!latestTab.active||latestTab.windowId!==tab.windowId||!latestPong?.fullscreen?.active)return {ok:true,ignored:true};
  win=await chrome.windows.get(tab.windowId);
  if(win.state==='fullscreen')return {ok:true,existing:true};
  await releaseDuoFullscreen();
  const owner={tabId:tab.id,windowId:tab.windowId,state:win.state==='maximized'?'maximized':'normal'};
  await chrome.storage.session.set({[FULLSCREEN_OWNER_KEY]:owner});
  try{await chrome.windows.update(tab.windowId,{state:'fullscreen'});}
  catch(e){await chrome.storage.session.remove(FULLSCREEN_OWNER_KEY);throw e;}
  return {ok:true,expanded:true};
});}
chrome.tabs.onRemoved.addListener(tabId=>{queueFullscreen(()=>releaseDuoFullscreen(tabId));});
chrome.tabs.onUpdated.addListener((tabId,change)=>{if(change.status==='loading')queueFullscreen(()=>releaseDuoFullscreen(tabId));});
chrome.tabs.onActivated.addListener(info=>{queueFullscreen(async()=>{
  const owner=(await chrome.storage.session.get(FULLSCREEN_OWNER_KEY))[FULLSCREEN_OWNER_KEY];
  if(owner&&info.windowId===owner.windowId&&info.tabId!==owner.tabId)await releaseDuoFullscreen(owner.tabId);
});});
