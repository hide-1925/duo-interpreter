(() => {
  'use strict';
  window.__duoHtmlContent?.dispose?.();
  let chain=Promise.resolve(),stopped=false;
  function command(data){window.dispatchEvent(new CustomEvent('duo-html-source-command',{detail:JSON.stringify(data)}));}
  function receive(event){
    if(stopped||typeof event.detail!=='string'||event.detail.length>4000000)return;
    let data;try{data=JSON.parse(event.detail);}catch(_){return;}
    chain=chain.then(async()=>{
      if(stopped)return;
      try{
        const reply=await chrome.runtime.sendMessage({type:'DUO_HTML_DATA',data});
        if(!reply?.ok){command({action:'dispose'});dispose();}
      }catch(_){command({action:'dispose'});dispose();}
    });
  }
  function message(m,_sender,respond){
    if(m.type==='DUO_HTML_COMMAND'){command(m.command||{});respond({ok:true});}
    if(m.type==='DUO_HTML_PING')respond({ok:true,version:'1.1.0'});
  }
  function dispose(){stopped=true;window.removeEventListener('duo-html-source-data',receive);try{chrome.runtime.onMessage.removeListener(message);}catch(_){} }
  window.addEventListener('duo-html-source-data',receive);
  chrome.runtime.onMessage.addListener(message);
  window.__duoHtmlContent={dispose};
})();
