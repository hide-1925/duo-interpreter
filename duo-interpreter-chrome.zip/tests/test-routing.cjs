const path=require('node:path');
const assert=require('node:assert/strict'),fs=require('fs'),vm=require('vm'),crypto=require('crypto');
const rows=[];function test(name,fn){fn();rows.push(name);}
const ctx=vm.createContext({crypto,console,window:{addEventListener(){}},CFG:{sttProvider:'openai'},dlog(){},setTimeout,clearTimeout,Map,WeakMap});
vm.runInContext(fs.readFileSync(path.join(__dirname,'../app.js'),'utf8').split('function duoInstallDisclosure')[0],ctx);
function run(s){return vm.runInContext(s,ctx);}
test('3 participants: P1 local, P2/P3 remote; same-language independent',()=>{
 run("duoSession=duoSessionConfig('web');duoSession.participants.p3={participantId:'p3'};duoSession.bindings.p3='conference-audio';duoSession.view.C='p3';");
 for(const [view,want] of [['A',true],['B',false],['C',false]])assert.equal(run(`AudioRoutingPolicy.resolve(Object.assign({utteranceId:'u',sourceLanguage:'ja',outputLanguage:'ja'},AudioEndpointManager.origin('${view}',false))).conferenceMic`),want);
});
test('Configuration alone changes local participant from P1 to P2',()=>{
 run("duoSession.bindings.p1='conference-audio';duoSession.bindings.p2='local-mic';");
 for(const [view,want] of [['A',false],['B',true],['C',false]])assert.equal(run(`AudioRoutingPolicy.resolve(Object.assign({utteranceId:'u'},AudioEndpointManager.origin('${view}',false))).conferenceMic`),want);
});
test('Unknown or incomplete origin fails closed',()=>{for(const job of [null,{}, {sourceScope:'local'}, {sourceScope:'remote',sourceParticipantId:'p1',sourceEndpointId:'mic',utteranceId:'u',sessionId:'s'}]){ctx.job=job;assert.equal(run('AudioRoutingPolicy.resolve(job).conferenceMic'),false);}});
test('Typed B-language text retains local endpoint identity',()=>{run("duoSession.textParticipantId='p2';");assert.equal(run("AudioEndpointManager.origin('A',true).sourceParticipantId"),'p2');assert.equal(run("AudioEndpointManager.origin('A',true).sourceScope"),'local');});
test('Origins are immutable snapshots after preset changes',()=>{run("var old=AudioEndpointManager.origin('B',false);duoSession=duoSessionConfig('one_to_many');");assert.equal(run('old.sourceScope'),'local');assert.equal(run('Object.isFrozen(old)'),true);assert.equal(run("AudioEndpointManager.forView('B')"),null);});
test('Separate local monitor and conference gate; remote never connected',()=>{
 const connected=[],gain={gain:{value:0},connect:n=>connected.push(n)},destination={stream:{getAudioTracks:()=>[{id:'conference'}]}},audio={createGain:()=>gain,createMediaStreamDestination:()=>destination};ctx.node={context:audio,connect:n=>connected.push(n)};
 ctx.localJob={sourceScope:'local',sourceParticipantId:'p1',sourceEndpointId:'mic',utteranceId:'u',sessionId:'s'};
 run('ConferenceMicBus.connect(node,localJob)');assert.equal(gain.gain.value,0);assert.equal(connected.length,2);
 run('ConferenceMicBus.setEnabled(true)');assert.equal(gain.gain.value,1);
 run("ConferenceMicBus.connect(node,{sourceScope:'remote'})");assert.equal(connected.length,2);
 run('ConferenceMicBus.setEnabled(false)');assert.equal(gain.gain.value,0);
});
test('STT adapters declare microphone and track capabilities',()=>{assert.equal(run('STT_ADAPTER_CAPABILITIES.webspeech.microphone'),true);assert.equal(run('STT_ADAPTER_CAPABILITIES.webspeech.systemAudio'),false);assert.equal(run('STT_ADAPTER_CAPABILITIES.openai.arbitraryTrack'),true);});
console.log(JSON.stringify({passed:rows.length,tests:rows},null,2));
