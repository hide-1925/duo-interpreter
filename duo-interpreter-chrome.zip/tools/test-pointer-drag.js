const fs=require('fs'),vm=require('vm'),assert=require('node:assert/strict');
const code=fs.readFileSync(require('path').join(__dirname,'../content-overlay.js'),'utf8');
const listeners=new Map(),targetListeners=new Map();let captured=null,moves=0,ends=0;
const target={addEventListener:(k,v)=>targetListeners.set(k,v),removeEventListener:k=>targetListeners.delete(k),setPointerCapture:id=>captured=id,hasPointerCapture:id=>captured===id,releasePointerCapture:()=>captured=null};
const ctx={root:{classList:{add(){},remove(){}}},addEventListener:(k,v)=>listeners.set(k,v),removeEventListener:k=>listeners.delete(k)};
vm.createContext(ctx);vm.runInContext(code.slice(code.indexOf('  let activeDragEnd'),code.indexOf("  toolbar.addEventListener")),ctx);
const ev=(id=7)=>({pointerId:id,pointerType:'mouse',buttons:1,preventDefault(){},stopPropagation(){},currentTarget:target});
const begin=()=>ctx.pointerDrag(ev(),()=>moves++,()=>ends++);
begin();assert.equal(captured,7);
for(let i=0;i<100;i++)listeners.get('pointermove')(ev());
assert.equal(moves,100);listeners.get('pointerup')(ev(8));assert.equal(ends,0);
listeners.get('pointerup')(ev());assert.equal(ends,1);assert.equal(captured,null);assert.equal(listeners.size,0);
for(const reason of ['pointercancel','blur','lostpointercapture']){begin();(reason==='lostpointercapture'?targetListeners:listeners).get(reason)(reason==='blur'?{}:ev());assert.equal(listeners.size,0);assert.equal(captured,null);}
begin();listeners.get('pointermove')({...ev(),buttons:0});assert.equal(listeners.size,0);
console.log('PASS: capture, sustained movement, unrelated pointer, release, cancel, blur, lost capture, missed mouse release');
