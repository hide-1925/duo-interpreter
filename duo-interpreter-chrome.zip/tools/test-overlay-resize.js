'use strict';
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('node:assert/strict');
const code=fs.readFileSync(path.join(__dirname,'../content-overlay.js'),'utf8');
const source=code.slice(code.indexOf('  for (const resizeHandle of resizeHandles)'),code.indexOf("  lockButton.addEventListener"));
const close=(a,b)=>assert(Math.abs(a-b)<1e-7,`${a} != ${b}`);
let passed=0;
for(const percent of [35,60,100])for(const corner of ['nw','ne','sw','se'])for(const movement of [40,-40,2000]){
 let move;const handlers={};const ratio=percent/100;
 const geometry={locked:false,left:null,right:18,top:180,width:400,height:260};
 const west=corner.includes('w'),north=corner.includes('n');
 const start={left:300,top:180,right:300+400*ratio,bottom:440};
 vm.runInNewContext(source,{geometry,profile:{itemWidth:percent},innerWidth:1400,innerHeight:900,
  resizeHandles:[{dataset:{corner},addEventListener:(_,fn)=>handlers[corner]=fn}],root:{getBoundingClientRect:()=>({left:300,top:180})},pointerDrag:(_,fn)=>move=fn,applyGeometry(){},saveGeometry(){}});
 handlers[corner]({clientX:600,clientY:500,button:0});
 move({clientX:600+(west?-movement:movement),clientY:500+(north?-movement:movement)});
 const actual={left:geometry.left,top:geometry.top,right:geometry.left+geometry.width*ratio,bottom:geometry.top+geometry.height};
 close(west?actual.right:actual.left,west?start.right:start.left);
 close(north?actual.bottom:actual.top,north?start.bottom:start.top);
 assert(actual.left>=-1e-7&&actual.top>=-1e-7&&actual.right<=1400+1e-7&&actual.bottom<=900+1e-7);
 assert(geometry.width>=240-1e-7&&geometry.height>=120-1e-7);
 if(Math.abs(movement)<100){close(geometry.width*ratio,400*ratio+movement);close(geometry.height,260+movement);}
 passed++;
}
let down,dragged=false;
vm.runInNewContext(source,{resizeHandles:[{addEventListener:(_,fn)=>down=fn}],geometry:{locked:true},pointerDrag:()=>dragged=true});
down({button:0});assert(!dragged);passed++;
console.log(JSON.stringify({ok:true,passed,scope:'Actual corner handlers in Node VM: 4 corners x 3 comment widths x grow/shrink/bounds, plus lock; browser rendering untested'},null,2));
