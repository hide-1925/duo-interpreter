'use strict';
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),path=require('node:path');
const read=n=>fs.readFileSync(path.join(__dirname,'..',n),'utf8'),passed=[];
async function test(name,fn){await fn();passed.push(name);}
function fixture(){
 const frames=[{frameId:0,parentFrameId:-1,documentId:'top-1',url:'https://teams.microsoft.com/chat'},
  {frameId:12,parentFrameId:0,documentId:'player-1',url:'https://tenant.sharepoint.com/player?token=not-for-report'},
  {frameId:13,parentFrameId:0,documentId:'other-1',url:'https://www.youtube.com/embed/other'}];
 const allowed=new Set(),installed=new Map(),full=new Map(),messages=[],injections=[],events={},saved={};
 const state={targetTabId:1,overlayEnabled:true,htmlTabId:5,htmlEntries:[{id:'1',srcText:'hello',dstText:'こんにちは'}]};
 const win={id:7,state:'normal'},updates=[];
 function findTarget(target){return target.documentIds?frames.find(f=>target.documentIds.includes(f.documentId)):frames.find(f=>(target.frameIds||[0]).includes(f.frameId));}
 const chrome={permissions:{contains:async p=>p.origins.every(o=>allowed.has(o)),onRemoved:{addListener:f=>events.revoked=f}},
  webNavigation:{getAllFrames:async()=>frames.map(f=>({...f})),getFrame:async x=>frames.find(f=>f.frameId===x.frameId),onCompleted:{addListener:f=>events.completed=f}},
  storage:{session:{get:async k=>({[k]:saved[k]}),set:async p=>Object.assign(saved,p),remove:async k=>delete saved[k]}},
  windows:{get:async()=>({...win}),update:async(id,p)=>{updates.push(p.state);Object.assign(win,p);}},
  tabs:{get:async()=>({id:1,url:frames[0].url,windowId:7,active:true}),
   onRemoved:{addListener(){}},onUpdated:{addListener(){}},onActivated:{addListener(){}},
   sendMessage:async(tabId,m,opts)=>{
    assert.equal(tabId,1);assert(Number.isInteger(opts?.frameId),'every overlay message must name a frame');
    const f=frames.find(f=>f.frameId===opts.frameId);
    if(!f||opts.documentId&&opts.documentId!==f.documentId||installed.get(f.frameId)!==f.documentId)throw Error('frame unavailable');
    if(m.type==='DUO_PING')return {ok:true,htmlBridgeVersion:'1.2.8',captions:1,fullscreen:full.get(f.frameId)||{active:false,element:null,visible:f.frameId===0}};
    messages.push({frameId:f.frameId,type:m.type,entries:m.entries});return {ok:true};
   }},
  scripting:{insertCSS:async opts=>{assert.equal(opts.origin,'AUTHOR');const f=findTarget(opts.target);assert(f);injections.push({kind:'css',frameId:f.frameId,target:opts.target});},
   executeScript:async opts=>{const f=findTarget(opts.target);assert(f);installed.set(f.frameId,f.documentId);injections.push({kind:'js',frameId:f.frameId,target:opts.target});}}};
 const c=vm.createContext({chrome,URL,Date,getState:async()=>state,setState:async p=>Object.assign(state,p),queueHtmlOperation:async f=>f()});
 const worker=read('service-worker.js');vm.runInContext(worker.slice(worker.indexOf('function isRestrictedUrl'),worker.indexOf('async function sendToTarget')),c);
 vm.runInContext(read('overlay-frames.js'),c);vm.runInContext(read('fullscreen-host.js'),c);
 c.deliverHtml=async()=>c.sendOverlayMessage(1,{type:'DUO_HTML_BATCH',entries:state.htmlEntries,visible:true});
 return {c,frames,allowed,installed,full,messages,injections,state,events,win,updates,
  grant:async()=>{allowed.add('https://tenant.sharepoint.com/*');allowed.add('https://www.youtube.com/*');await c.ensureOverlayFrames(1,true);},
  sender:(id=12)=>({tab:{id:1},frameId:id,documentId:frames.find(f=>f.frameId===id)?.documentId})};
}
(async()=>{
 await test('unpermitted player is discovered but never injected',async()=>{
  const x=fixture(),rows=await x.c.ensureOverlayFrames(1);assert.equal(x.installed.size,1);assert(!rows.find(f=>f.frameId===12).allowed);
  assert(!JSON.stringify(rows).includes('token='));assert.equal(rows.find(f=>f.frameId===12).origin,'https://tenant.sharepoint.com');
 });
 await test('granted player origins use exact document IDs, not allFrames',async()=>{
  const x=fixture();await x.grant();assert.equal(x.installed.size,3);assert(x.injections.every(i=>i.target.documentIds?.length===1&&!i.target.allFrames));
 });
 await test('about:blank and blob players use inherited or embedded HTTPS origin',async()=>{
  const x=fixture();x.frames.push({frameId:14,parentFrameId:12,documentId:'blank-1',url:'about:blank'});x.frames.push({frameId:15,parentFrameId:12,documentId:'blob-1',url:'blob:https://tenant.sharepoint.com/opaque'});await x.grant();assert(x.installed.has(14));assert(x.installed.has(15));
 });
 await test('frame errors remove signed URL paths and tokens from diagnostics',async()=>{
  const x=fixture();const error=x.c.frameError(Error('Denied https://tenant.sharepoint.com/recording?token=secret'));assert(!error.includes('secret'));assert(!error.includes('recording'));
 });
 await test('inactive embedded frames receive no subtitle text',async()=>{
  const x=fixture();await x.grant();await x.c.deliverHtml();assert.deepEqual(x.messages.map(m=>m.frameId),[0]);
 });
 await test('fullscreen SharePoint player receives current captions while unrelated YouTube frame does not',async()=>{
  const x=fixture();await x.grant();x.full.set(0,{active:true,element:'IFRAME',visible:false});x.full.set(12,{active:true,element:'DIV',visible:true});
  await x.c.deliverHtml();assert.deepEqual(x.messages.map(m=>m.frameId).sort((a,b)=>a-b),[0,12]);
 });
 await test('same route works for a YouTube embed or another permitted player origin',async()=>{
  const x=fixture();await x.grant();x.full.set(13,{active:true,element:'DIV',visible:true});await x.c.deliverHtml();assert.deepEqual(x.messages.map(m=>m.frameId),[0,13]);
 });
 await test('nested fullscreen passes through intermediate iframe without caption duplication',async()=>{
  const x=fixture();x.frames[2].parentFrameId=12;await x.grant();x.full.set(12,{active:true,element:'IFRAME',visible:false});x.full.set(13,{active:true,element:'DIV',visible:true});
  await x.c.deliverHtml();assert.deepEqual(x.messages.map(m=>m.frameId),[0,13]);
 });
 await test('paused recording gets a caption replay on child fullscreen entry',async()=>{
  const x=fixture();await x.grant();x.full.set(12,{active:true,element:'DIV',visible:true});await x.c.syncDuoFullscreen({active:true},x.sender());
  assert(x.messages.some(m=>m.frameId===12&&m.entries.length===1));assert.equal(x.win.state,'fullscreen');assert.equal(x.state.duoFullscreenHistory.at(-1).frameId,12);
 });
 await test('child exit cannot restore browser window until remaining fullscreen frames exit',async()=>{
  const x=fixture();await x.grant();x.full.set(0,{active:true,element:'IFRAME'});x.full.set(12,{active:true,element:'DIV'});await x.c.syncDuoFullscreen({active:true},x.sender());
  x.full.set(12,{active:false});await x.c.syncDuoFullscreen({active:false},x.sender());assert.equal(x.win.state,'fullscreen');
  x.full.set(0,{active:false});await x.c.syncDuoFullscreen({active:false},x.sender(0));assert.equal(x.win.state,'normal');assert(x.state.duoFullscreenHistory.some(h=>h.active&&h.frameId===12));
 });
 await test('old document sender after player navigation is rejected',async()=>{
  const x=fixture();await x.grant();const old=x.sender();x.frames[1].documentId='player-2';await assert.rejects(()=>x.c.syncDuoFullscreen({active:true},old),/切り替わ/);
 });
 await test('navigation reloads the new player document rather than reusing an old frame reply',async()=>{
  const x=fixture();await x.grant();x.frames[1].documentId='player-2';await x.c.ensureOverlayFrames(1,true);assert.equal(x.installed.get(12),'player-2');
 });
 await test('permission revocation stops subsequent subtitle deliveries to that frame',async()=>{
  const x=fixture();await x.grant();x.full.set(12,{active:true,element:'DIV'});x.allowed.clear();x.events.revoked();await x.c.deliverHtml();assert.deepEqual(x.messages.map(m=>m.frameId),[0]);
 });
 await test('missing and unrelated-tab fullscreen senders are rejected',async()=>{
  const x=fixture();await x.grant();await assert.rejects(()=>x.c.syncDuoFullscreen({active:true},{tab:{id:2},frameId:12}));await assert.rejects(()=>x.c.syncDuoFullscreen({active:true},{tab:{id:1},frameId:99}));
 });
 console.log(JSON.stringify({ok:true,passed:passed.length,tests:passed,scope:'Real worker/frame routing in Node VM with mocked Chrome APIs; no authenticated site rendering'},null,2));
})().catch(e=>{console.error(e);process.exitCode=1;});
