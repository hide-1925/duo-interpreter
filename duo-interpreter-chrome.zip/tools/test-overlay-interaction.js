'use strict';
// Tests real injection/geometry/event handlers, not a browser hit-test simulation.
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),path=require('node:path');
const read=n=>fs.readFileSync(path.join(__dirname,'..',n),'utf8');
const worker=read('service-worker.js'),overlay=read('content-overlay.js');
(async()=>{
 const calls=[];let ping=null;
 const c=vm.createContext({chrome:{tabs:{get:async()=>({url:'https://video.test/'}),sendMessage:async()=>ping},scripting:{insertCSS:async x=>calls.push(x),executeScript:async()=>{}}}});
 vm.runInContext(worker.slice(worker.indexOf('function isRestrictedUrl'),worker.indexOf('async function sendToTarget')),c);
 await c.injectOverlay(1);
 // USER !important defeats inline !important, including all:initial. This is
 // the regression missed by prior drag tests that did not inspect CSS origin.
 assert.equal(calls[0].origin,'AUTHOR','stylesheet must allow inline geometry to win');
 ping={ok:true,htmlBridgeVersion:'1.2.5'};
 await assert.rejects(()=>c.injectOverlay(1),/再読み込み/);
 const props=new Map(),classes=new Set(),attributes={};
 const geometry={width:440,height:320,top:90,left:160,right:18,locked:false};
 const g=vm.createContext({geometry,root:{style:{setProperty:(k,v,p)=>props.set(k,{value:v,priority:p}),removeProperty:k=>props.delete(k)},classList:{toggle:(k,on)=>on?classes.add(k):classes.delete(k)}},lockButton:{setAttribute:(k,v)=>attributes[k]=v,classList:{toggle(){}}}});
 vm.runInContext(overlay.slice(overlay.indexOf('  function applyGeometry'),overlay.indexOf('  function applyLayout')),g);
 g.applyGeometry();assert.equal(props.get('width').value,'440px');assert.equal(props.get('left').value,'160px');assert.equal(props.get('width').priority,'important');
 geometry.width=600;geometry.top=130;g.applyGeometry();assert.equal(props.get('width').value,'600px');assert.equal(props.get('top').value,'130px');
 assert.equal(attributes['aria-pressed'],'false');geometry.locked=true;g.applyGeometry();assert.equal(attributes['aria-pressed'],'true');assert(classes.has('duo-locked'));
 const listeners=()=>({events:{},addEventListener(k,f){this.events[k]=f;}}),root=listeners(),canvas=listeners();
 vm.runInNewContext(overlay.slice(overlay.indexOf('  for (const surface of [root, canvas])'),overlay.indexOf("  const feed = root.querySelector")),{root,canvas});
 for(const node of [root,canvas])for(const type of ['pointerdown','pointerup','click','dblclick','contextmenu']){
  let stopped=false;node.events[type]({stopPropagation(){stopped=true;},preventDefault(){throw Error('must preserve default focus');}});assert(stopped);
 }
 assert(!root.events.keydown);assert(!root.events.keyup);
 console.log('PASS: actual CSS injection origin, stale overlay rejection, geometry updates, lock state, mouse event isolation without keyboard interception (no real hit-testing)');
})().catch(e=>{console.error(e);process.exitCode=1;});
