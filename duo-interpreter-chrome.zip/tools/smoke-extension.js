#!/usr/bin/env node
'use strict';

const path = require('path');
const fs = require('fs');
const os = require('os');
const { chromium } = require('playwright');

(async () => {
  const extensionPath = path.resolve(__dirname, '..');
  const userDataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'duo-chrome-test-'));
  const context = await chromium.launchPersistentContext(userDataDir, {
    headless: false,
    args: [
      '--headless=new',
      `--disable-extensions-except=${extensionPath}`,
      `--load-extension=${extensionPath}`,
      '--no-first-run',
      '--no-default-browser-check'
    ]
  });
  try {
    let workers = context.serviceWorkers();
    if (!workers.length) workers = [await context.waitForEvent('serviceworker', { timeout: 10000 })];
    const worker = workers[0];
    const extensionId = new URL(worker.url()).host;
    const page = await context.newPage();
    const errors = [];
    page.on('pageerror', (error) => errors.push(String(error)));
    page.on('console', (message) => { if (message.type() === 'error') errors.push(message.text()); });
    await page.goto(`chrome-extension://${extensionId}/app.html`);
    await page.waitForSelector('#mic');
    const app = await page.evaluate(() => ({
      title: document.title,
      dock: !!document.getElementById('duoExtensionDock'),
      mic: document.getElementById('mic').textContent,
      version: document.body.textContent.includes('v1.0.3')
    }));

    const popup = await context.newPage();
    await popup.goto(`chrome-extension://${extensionId}/popup.html`);
    await popup.waitForSelector('#setTarget');
    const popupState = await popup.evaluate(() => ({
      title: document.title,
      buttons: document.querySelectorAll('button').length,
      current: document.getElementById('currentTab').textContent
    }));

    const result = { ok: errors.length === 0 && app.dock && app.version && popupState.buttons === 5, extensionId, app, popup: popupState, errors };
    console.log(JSON.stringify(result, null, 2));
    if (!result.ok) process.exitCode = 1;
  } finally {
    await context.close();
    fs.rmSync(userDataDir, { recursive: true, force: true });
  }
})().catch((error) => { console.error(error); process.exit(1); });
