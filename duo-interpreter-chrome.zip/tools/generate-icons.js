#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

const root = path.resolve(__dirname, '..');
const iconDir = path.join(root, 'icons');
fs.mkdirSync(iconDir, { recursive: true });

const table = new Uint32Array(256);
for (let n = 0; n < 256; n++) {
  let c = n;
  for (let k = 0; k < 8; k++) c = (c & 1) ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
  table[n] = c >>> 0;
}

function crc32(buffer) {
  let c = 0xffffffff;
  for (const byte of buffer) c = table[(c ^ byte) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function chunk(type, data) {
  const name = Buffer.from(type);
  const out = Buffer.alloc(data.length + 12);
  out.writeUInt32BE(data.length, 0); name.copy(out, 4); data.copy(out, 8);
  out.writeUInt32BE(crc32(Buffer.concat([name, data])), data.length + 8);
  return out;
}

function makeIcon(size) {
  const raw = Buffer.alloc((size * 4 + 1) * size);
  for (let y = 0; y < size; y++) {
    const row = y * (size * 4 + 1); raw[row] = 0;
    for (let x = 0; x < size; x++) {
      const p = row + 1 + x * 4;
      const edge = Math.min(x, y, size - 1 - x, size - 1 - y);
      const radius = size * .2;
      const corner = edge < 0 || ((x < radius && y < radius && Math.hypot(radius - x, radius - y) > radius)
        || (x > size - radius && y < radius && Math.hypot(x - (size - radius), radius - y) > radius)
        || (x < radius && y > size - radius && Math.hypot(radius - x, y - (size - radius)) > radius)
        || (x > size - radius && y > size - radius && Math.hypot(x - (size - radius), y - (size - radius)) > radius));
      if (corner) { raw[p + 3] = 0; continue; }
      const top = y < size / 2;
      const rgb = top ? [61, 220, 151] : [94, 184, 255];
      raw[p] = rgb[0]; raw[p + 1] = rgb[1]; raw[p + 2] = rgb[2]; raw[p + 3] = 255;
      if (Math.abs(y - size / 2) < Math.max(1, size / 32)) raw[p] = raw[p + 1] = raw[p + 2] = 11;
    }
  }
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(size, 0); ihdr.writeUInt32BE(size, 4); ihdr[8] = 8; ihdr[9] = 6;
  return Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]), chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw, { level: 9 })), chunk('IEND', Buffer.alloc(0))]);
}

for (const size of [16, 32, 48, 128]) fs.writeFileSync(path.join(iconDir, `icon-${size}.png`), makeIcon(size));
console.log(`Generated icons in ${iconDir}`);
