#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');
const vm = require('vm');

const root = path.resolve(__dirname, '..');
const failures = [];
const checks = [];
const check = (name, condition, detail = '') => {
  checks.push({ name, ok: !!condition, detail });
  if (!condition) failures.push(`${name}${detail ? `: ${detail}` : ''}`);
};
const read = (name) => fs.readFileSync(path.join(root, name), 'utf8');

const manifest = JSON.parse(read('manifest.json'));
check('Manifest V3', manifest.manifest_version === 3);
check('Extension version', manifest.version === '1.2.10');
check('Minimum Chrome 116', Number(manifest.minimum_chrome_version) >= 116);
for (const permission of ['activeTab', 'scripting', 'storage', 'tabCapture', 'webNavigation']) {
  check(`Permission: ${permission}`, manifest.permissions.includes(permission));
}

const referenced = [
  manifest.background.service_worker,
  manifest.action.default_popup,
  manifest.options_page,
  'app.css', 'app.js', 'extension-bridge.js',
  'overlay-style.js', 'overlay-frames.js', 'fullscreen-host.js', 'overlay-fullscreen.js', 'html-caption-command.js', 'popup.css', 'popup.js', 'content-overlay.css', 'content-overlay.js', 'target-speech-main.js',
  'icons/icon-16.png', 'icons/icon-32.png', 'icons/icon-48.png', 'icons/icon-128.png'
];
for (const name of referenced) check(`File exists: ${name}`, fs.existsSync(path.join(root, name)));

const appHtml = read('app.html');
check('No executable inline script', !/<script(?![^>]*\bsrc=)[^>]*>/i.test(appHtml));
check('No inline style block', !/<style\b/i.test(appHtml));
check('External app script', appHtml.includes('<script src="app.js"></script>'));
check('External extension bridge', appHtml.includes('<script src="extension-bridge.js"></script>'));
check('Embedded config is inert', /<pre id="embedded-config" hidden>/.test(appHtml));

for (const name of ['overlay-style.js','overlay-frames.js','fullscreen-host.js','overlay-fullscreen.js','html-caption-command.js','html-host.js','html-source-main.js','html-source-content.js','service-worker.js', 'popup.js', 'content-overlay.js', 'target-speech-main.js', 'extension-bridge.js', 'app.js']) {
  const source = read(name);
  try { new vm.Script(source, { filename: name }); check(`JavaScript syntax: ${name}`, true); }
  catch (error) { check(`JavaScript syntax: ${name}`, false, error.message); }
}

const appJs = read('app.js');
check('Target-tab capture hook', appJs.includes('DuoExtension.captureTargetAudio'));
check('Target-tab Web Speech engine', appJs.includes('TargetTabWebSpeechEngine'));
check('Caption publish hook', appJs.includes('DuoExtension.publishEntry'));
check('Caption removal hook', appJs.includes('DuoExtension.removeEntry'));
check('Profile synchronization hook', appJs.includes('DuoExtension.publishProfile'));
check('Main overlay settings section', appHtml.includes('id="overlaySettingsMain"'));
check('Main overlay hold control', appHtml.includes('id="cfgOvCapHold"'));
check('Overlay setting mirror binding', appJs.includes('captureControlElements'));

const worker = read('service-worker.js');
for (const type of ['DUO_SET_TARGET','DUO_GET_STREAM_ID','DUO_START_TARGET_WEB_SPEECH','DUO_STOP_TARGET_WEB_SPEECH','DUO_TARGET_SPEECH_EVENT','DUO_ENTRY','DUO_REMOVE_ENTRY','DUO_PROFILE','DUO_CLEAR_ENTRIES','DUO_TOGGLE_OVERLAY','DUO_RESET_OVERLAY','DUO_OPEN_SETTINGS']) {
  check(`Message route: ${type}`, worker.includes(`'${type}'`));
}

const popupHtml = read('popup.html');
check('Popup overlay settings shortcut', popupHtml.includes('id="openOverlaySettings"'));

const styleContext={};vm.runInNewContext(read('overlay-style.js'),styleContext);
check('Shadow DOM stylesheet matches document stylesheet',styleContext.DuoOverlayCssText===read('content-overlay.css'));
const overlay = read('content-overlay.js');
check('Overlay idempotence', overlay.includes('__duoChromeOverlayInstalled'));
check('No confirmation on annotation clear', !/confirm\s*\(/.test(overlay));
check('Drag positioning', overlay.includes("toolbar.addEventListener('pointerdown'"));
check('Width and height resizing', overlay.includes("resizeHandle.addEventListener('pointerdown'"));
check('Annotation pen', overlay.includes("canvas.addEventListener('pointerdown'"));
check('Overlay geometry persistence', overlay.includes('chrome.storage.local.set'));
check('Content script relays MAIN-world speech commands', overlay.includes('duo-target-speech-main-command'));
check('Content script relays MAIN-world speech results', overlay.includes('duo-target-speech-main-event'));
check('Target consumer tab capture', worker.includes('consumerTabId: state.targetTabId'));
check('MAIN-world speech injection', worker.includes("world: 'MAIN'") && worker.includes("files: ['target-speech-main.js']"));
check('Speech result forwarding uses a distinct app message', worker.includes('DUO_TARGET_SPEECH_EVENT_APP'));

const targetSpeechMain = read('target-speech-main.js');
check('Web Speech runs in page MAIN world', targetSpeechMain.includes('recognition.start(current.track)'));
check('MAIN-world script is idempotent', targetSpeechMain.includes('__duoTargetSpeechMainInstalled'));
check('Capture comparison selector', appHtml.includes('id="extensionSpeechCapture"'));
check('Display capture with explicit user gesture', targetSpeechMain.includes('getDisplayMedia(') && targetSpeechMain.includes('startButton.onclick'));
check('Both methods use original track', !targetSpeechMain.includes('captureStream()') && targetSpeechMain.includes('recognition.start(current.track)'));
check('Actual recognition onstart event', targetSpeechMain.includes('recognition.onstart'));
check('Diagnostic data snapshots', appJs.includes('JSON.parse(JSON.stringify(data))'));

const ids = [...appHtml.matchAll(/\bid="([^"]+)"/g)].map((match) => match[1]);
const duplicates = ids.filter((id, index) => ids.indexOf(id) !== index);
check('No duplicate app DOM ids', duplicates.length === 0, [...new Set(duplicates)].join(','));

const domRefs = [...appJs.matchAll(/\$\('([^']+)'\)/g)].map((match) => match[1]);
const missing = [...new Set(domRefs.filter((id) => !ids.includes(id)))];
check('No missing static $() DOM references', missing.length === 0, missing.join(','));

const result = {
  ok: failures.length === 0,
  passed: checks.filter((item) => item.ok).length,
  total: checks.length,
  checks,
  failures
};
console.log(JSON.stringify(result, null, 2));
process.exitCode = result.ok ? 0 : 1;
