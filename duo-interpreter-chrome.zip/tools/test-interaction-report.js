'use strict';
const fs=require('fs'),vm=require('vm'),assert=require('node:assert/strict'),path=require('path');
const code=fs.readFileSync(path.join(__dirname,'../content-overlay.js'),'utf8');
const listeners=new Map(),rootEvents=new Map();
const geometry={left:120,top:80,width:400,height:250,locked:false};
let rect={left:120,top:80,width:400,height:250},captured=false;
const target={addEventListener(){},removeEventListener(){},setPointerCapture(){captured=true;},hasPointerCapture(){return captured;},releasePointerCapture(){captured=false;}};
const c=vm.createContext({geometry,innerWidth:1400,innerHeight:900,
 root:{id:'duo-caption-surface',getBoundingClientRect:()=>rect,addEventListener:(k,f)=>rootEvents.set(k,f),classList:{add(){},remove(){}}},
 getComputedStyle:()=>({position:'fixed',width:rect.width+'px',height:rect.height+'px',pointerEvents:'none'}),
 addEventListener:(k,f)=>listeners.set(k,f),removeEventListener:k=>listeners.delete(k)});
vm.runInContext(code.slice(code.indexOf('  let activeDragEnd'),code.indexOf('  toolbar.addEventListener')),c);
const ev={pointerId:7,pointerType:'mouse',buttons:1,preventDefault(){},stopPropagation(){},currentTarget:target};
assert.equal(c.interactionSnapshot().drag.starts,0);assert.equal(c.interactionSnapshot().mismatch,false);
c.pointerDrag(ev,()=>{geometry.left=160;rect={...rect,left:160};});listeners.get('pointermove')(ev);
let report=c.interactionSnapshot();assert.equal(report.drag.starts,1);assert.equal(report.drag.moves,1);assert.equal(report.mismatch,false);
geometry.width=500;report=c.interactionSnapshot();assert.equal(report.mismatch,true);assert.equal(report.wanted.width,500);assert.equal(report.actual.width,400);
listeners.get('pointerup')(ev);assert.equal(c.interactionSnapshot().drag.phase,'ended');assert(!captured);
c.pointerDrag(ev,()=>{throw Error('test geometry error');});listeners.get('pointermove')(ev);
assert.equal(c.interactionSnapshot().drag.lastError,'test geometry error');assert(!captured);assert.equal(listeners.size,0);
assert.deepEqual(Object.keys(report).sort(),['actual','css','drag','locked','mismatch','surfaceId','viewport','wanted']);
console.log('PASS: report distinguishes no drag, delivered moves, applied geometry, mismatch and callback failure without subtitle text');
