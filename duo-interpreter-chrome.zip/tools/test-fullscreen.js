'use strict';
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),path=require('node:path');
const read=n=>fs.readFileSync(path.join(__dirname,'..',n),'utf8');
const flush=async()=>{for(let i=0;i<30;i++)await Promise.resolve();};
let passed=0;
async function test(name,fn){await fn();passed++;console.log('PASS',name);}
function renderer(popover=true){
 const events={},pageEvents={},messages=[];
 class Element{
  constructor(tag='DIV'){this.tagName=tag;this.children=[];this.parentNode=null;this.open=false;this.classes=new Set();this.classList={contains:k=>this.classes.has(k)};}
  appendChild(n){n.remove();this.children.push(n);n.parentNode=this;}
  remove(){if(this.parentNode){const p=this.parentNode;p.children.splice(p.children.indexOf(this),1);this.parentNode=null;}}
  get isConnected(){return !!this.parentNode;}
  setAttribute(k,v){this[k]=v;}matches(){return this.open;}
  showPopover(){this.open=true;}hidePopover(){this.open=false;}
 }
 if(!popover)delete Element.prototype.showPopover;
 const doc={documentElement:new Element('HTML'),fullscreenElement:null,createElement:t=>new Element(t.toUpperCase()),
  addEventListener:(k,fn)=>events[k]=fn,removeEventListener:k=>delete events[k]};
 const c={document:doc,HTMLElement:Element,addEventListener:(k,f)=>pageEvents[k]=f,chrome:{runtime:{sendMessage:async m=>{messages.push(m);return {ok:true};}}}};
 vm.createContext(c);vm.runInContext(read('overlay-fullscreen.js'),c);
 const root=new Element(),canvas=new Element('CANVAS');doc.documentElement.appendChild(canvas);doc.documentElement.appendChild(root);
 root.entries=['retained subtitle'];let sizes=0;
 const ctrl=c.DuoOverlayFullscreen(root,canvas,()=>sizes++);
 return {doc,root,canvas,ctrl,events,pageEvents,messages,Element,get sizes(){return sizes;},full(tag){doc.fullscreenElement=tag?new Element(tag):null;events.fullscreenchange();}};
}
function host(){
 const saved={},events={},updates=[];let active=true,domFull=true;
 const windows=new Map([[7,{id:7,state:'normal'}]]);
 const state={targetTabId:1,overlayEnabled:true};
 const chrome={storage:{session:{get:async k=>({[k]:saved[k]}),set:async x=>Object.assign(saved,x),remove:async k=>{delete saved[k];}}},
  tabs:{get:async id=>({id,active,windowId:7}),sendMessage:async()=>({fullscreen:{active:domFull}}),
   onRemoved:{addListener:fn=>events.removed=fn},onUpdated:{addListener:fn=>events.updated=fn},onActivated:{addListener:fn=>events.activated=fn}},
  windows:{get:async id=>({...windows.get(id)}),update:async(id,p)=>{updates.push([id,p.state]);Object.assign(windows.get(id),p);}}};
 const c={chrome,getState:async()=>state};vm.createContext(c);vm.runInContext(read('fullscreen-host.js'),c);
 return {saved,state,windows,events,updates,c,set active(v){active=v;},set domFull(v){domFull=v;},
  send(on,sender={tab:{id:1},frameId:0}){return c.syncDuoFullscreen({active:on},sender);}};
}
(async()=>{
 await test('target scripts do not intercept F/Esc keys or replace native fullscreen methods',()=>{
  for(const file of ['content-overlay.js','overlay-fullscreen.js','target-speech-main.js']){
   const code=read(file);
   assert(!/addEventListener\s*\(\s*['"]key(?:down|up|press)/.test(code),file);
   assert(!/\.(?:onkeydown|onkeyup|onkeypress|requestFullscreen|exitFullscreen)\s*=/.test(code),file);
   assert(!/\.(?:requestFullscreen|exitFullscreen|focus)\s*\(/.test(code),file);
  }
  const x=renderer();x.full('VIDEO');assert.equal(x.root.parentNode.popover,'manual');assert.equal(x.root.parentNode.parentNode,x.doc.fullscreenElement);
  assert(!read('content-overlay.js').includes('autofocus'));
 });
 await test('video fullscreen keeps existing subtitles and annotation canvas in top layer',()=>{
  const x=renderer();x.full('VIDEO');assert.equal(x.ctrl.snapshot().layer,'top-layer');assert.equal(x.root.parentNode,x.canvas.parentNode);
  assert.deepEqual(x.root.entries,['retained subtitle']);assert.equal(x.messages[0].active,true);
 });
 await test('iframe and player-container fullscreen use the same top layer',()=>{
  for(const tag of ['VIDEO','IFRAME','DIV']){const x=renderer();x.full(tag);assert.equal(x.ctrl.snapshot().layer,'top-layer');assert.equal(x.root.parentNode.parentNode,x.doc.fullscreenElement,'controls must be descendants of the fullscreen element');}
 });
 await test('switching fullscreen element reparents and reopens the same shell',()=>{
  const x=renderer();x.full('DIV');const shell=x.root.parentNode;const old=x.doc.fullscreenElement;
  x.full('VIDEO');assert.equal(x.root.parentNode,shell);assert.equal(shell.parentNode,x.doc.fullscreenElement);assert.equal(shell.open,true);assert.equal(old.children.length,0);
 });
 await test('subtitle updates do not remount or resize during a drag',()=>{
  for(const tag of [null,'DIV','VIDEO']){const x=renderer();x.full(tag);const parent=x.root.parentNode,canvasParent=x.canvas.parentNode,sizes=x.sizes;
   for(let i=0;i<250;i++)x.ctrl.sync();
   assert.equal(x.sizes,sizes,'text update must not reset geometry or canvas');assert.equal(x.root.parentNode,parent);assert.equal(x.canvas.parentNode,canvasParent);
  }
 });
 await test('closed fullscreen popover recovers without repeated text resets',()=>{
  const x=renderer();x.full('DIV');const shell=x.root.parentNode;const sizes=x.sizes;shell.hidePopover();x.ctrl.sync();assert(shell.open);assert.equal(x.sizes,sizes+1);x.ctrl.sync();assert.equal(x.sizes,sizes+1);
 });
 await test('exit restores same DOM nodes; repeated fullscreen does not duplicate captions',()=>{
  const x=renderer();for(let i=0;i<8;i++){x.full('DIV');x.full(null);}
  assert.equal(x.root.parentNode,x.doc.documentElement);assert.equal(x.doc.documentElement.children.length,2);assert.deepEqual(x.root.entries,['retained subtitle']);
 });
 await test('F11 viewport resize retains subtitles without a DOM fullscreen element',()=>{
  const x=renderer();x.ctrl.sync();x.ctrl.sync();assert.equal(x.ctrl.snapshot().layer,'page');assert.equal(x.messages.length,1);assert.equal(x.messages[0].active,false);
 });
 await test('explicitly hidden overlay never opens a popover',()=>{
  const x=renderer();x.root.classes.add('duo-hidden');x.full('VIDEO');assert.equal(x.doc.documentElement.children.length,2);
  x.root.classes.delete('duo-hidden');x.ctrl.sync();assert.equal(x.ctrl.snapshot().layer,'top-layer');
 });
 await test('older engine fallback mounts into container and reports unsupported video target',()=>{
  const x=renderer(false);x.full('DIV');assert.equal(x.root.parentNode,x.doc.fullscreenElement);
  x.full('VIDEO');assert(x.ctrl.snapshot().error.includes('更新'));assert.equal(x.root.parentNode,x.doc.documentElement);
 });
 await test('back-forward cache pagehide preserves fullscreen listeners',()=>{
  const x=renderer();x.pageEvents.pagehide({persisted:true});x.full('VIDEO');assert.equal(x.ctrl.snapshot().layer,'top-layer');
 });
 await test('captured tab gets actual browser fullscreen and restores normal state on exit',async()=>{
  const x=host();await x.send(true);assert.deepEqual(x.updates,[[7,'fullscreen']]);x.domFull=false;await x.send(false);assert.deepEqual(x.updates,[[7,'fullscreen'],[7,'normal']]);
 });
 await test('maximized window returns to maximized instead of normal',async()=>{
  const x=host();x.windows.get(7).state='maximized';await x.send(true);x.domFull=false;await x.send(false);assert.equal(x.windows.get(7).state,'maximized');
 });
 await test('preexisting F11 or native fullscreen is never owned or undone',async()=>{
  const x=host();x.windows.get(7).state='fullscreen';await x.send(true);x.domFull=false;await x.send(false);assert.equal(x.updates.length,0);
 });
 await test('wrong tab/frame, hidden overlay and background tab cannot change window state',async()=>{
  const x=host();await assert.rejects(()=>x.send(true,{tab:{id:99},frameId:0}));await assert.rejects(()=>x.send(true,{tab:{id:1},frameId:2}));
  x.state.overlayEnabled=false;await x.send(true);x.state.overlayEnabled=true;x.active=false;await x.send(true);assert.equal(x.updates.length,0);
 });
 await test('stale fullscreen event after rapid exit cannot enlarge a window',async()=>{
  const x=host();x.domFull=false;assert((await x.send(true)).ignored);assert.equal(x.updates.length,0);
 });
 await test('target navigation, tab close or switching away restores owned window state',async()=>{
  for(const kind of ['navigate','close','switch']){const x=host();await x.send(true);
   if(kind==='navigate')x.events.updated(1,{status:'loading'});if(kind==='close')x.events.removed(1);if(kind==='switch')x.events.activated({tabId:2,windowId:7});
   await flush();assert.equal(x.windows.get(7).state,'normal',kind);
  }
 });
 await test('user already leaving fullscreen is respected during cleanup',async()=>{
  const x=host();await x.send(true);x.windows.get(7).state='normal';x.domFull=false;await x.send(false);assert.equal(x.updates.length,1);
 });
 console.log(passed+' fullscreen checks passed (mock DOM/window API; real display unverified)');
})().catch(e=>{console.error(e);process.exitCode=1;});
