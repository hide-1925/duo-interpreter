#!/usr/bin/env node
'use strict';
// Behavioral tests with browser APIs mocked; these do NOT test Google's recognition service.
const fs=require('fs');
const path=require('path');
const vm=require('vm');
const assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..');
const code=fs.readFileSync(path.join(root,'target-speech-main.js'),'utf8');
const settle=async()=>{for(let i=0;i<12;i++)await Promise.resolve();};
const tests=[];
async function test(name,run){await run();tests.push(name);}
function harness(options={}){
  const listeners=new Map(),events=[],nodes=[],recognitions=[],calls=[],intervals=new Map(),timeouts=new Map();
  let tid=0;
  const track=(kind)=>({kind,readyState:'live',muted:false,enabled:true,stops:0,listeners:{},
    getSettings(){return kind==='video'?{displaySurface:'browser'}:{sampleRate:96000,channelCount:2,...options.trackSettings};},
    stop(){this.stops++;this.readyState='ended';},addEventListener(name,fn){this.listeners[name]=fn;}});
  const audio=track('audio'),video=track('video');
  const stream={getTracks:()=>options.noAudio?[video]:[audio,video],getAudioTracks:()=>options.noAudio?[]:[audio],getVideoTracks:()=>[video]};
  function node(tag){const n={tag,style:{},children:[],disabled:false,remove(){this.removed=true;},append(...items){this.children.push(...items);},appendChild(item){this.children.push(item);},attachShadow(){return node('shadow');}};nodes.push(n);return n;}
  const doc={createElement:node,documentElement:node('html')};
  const win={isSecureContext:true,addEventListener(name,fn){if(!listeners.has(name))listeners.set(name,[]);listeners.get(name).push(fn);},
    dispatchEvent(event){if(event.type==='duo-target-speech-main-event')events.push(JSON.parse(event.detail));for(const fn of listeners.get(event.type)||[])fn(event);}};
  class Recognition{constructor(){recognitions.push(this);}start(track){this.track=track;if(options.throwStart)throw new Error('start rejected');}abort(){this.aborted=true;}}
  class Context{constructor(){this.state='running';this.sampleRate=96000;this.destination={};}createMediaStreamSource(){return{connect(){},disconnect(){}};}createAnalyser(){return{fftSize:2048,getFloatTimeDomainData(buffer){buffer.fill(.1);}};}resume(){return Promise.resolve();}close(){this.state='closed';return Promise.resolve();}}
  win.SpeechRecognition=Recognition;win.AudioContext=Context;
  const nav={userActivation:{isActive:false},mediaDevices:{
    getDisplayMedia(constraints){calls.push({method:'display',constraints,activated:nav.userActivation.isActive});return options.pending || (options.reject?Promise.reject(Object.assign(new Error('cancelled'),{name:'NotAllowedError'})):Promise.resolve(stream));},
    getUserMedia(constraints){calls.push({method:'tab',constraints});return options.pending || Promise.resolve(stream);}
  }};
  const context=vm.createContext({window:win,navigator:nav,document:doc,location:{origin:'https://example.test'},
    performance:{now:()=>2000},MediaStream:class{constructor(tracks){this.tracks=tracks;}},
    CustomEvent:class{constructor(type,opts){this.type=type;this.detail=opts.detail;}},
    setTimeout(fn){timeouts.set(++tid,fn);return tid;},clearTimeout(id){timeouts.delete(id);},
    setInterval(fn){intervals.set(++tid,fn);return tid;},clearInterval(id){intervals.delete(id);}});
  vm.runInContext(code,context);
  const command=(payload)=>win.dispatchEvent({type:'duo-target-speech-main-command',detail:JSON.stringify(payload)});
  const start=(method='display',id='one')=>command({action:'start',captureMethod:method,sessionId:id,seat:'A',lang:'ja-JP',streamId:'test-id'});
  const stop=(id='one')=>command({action:'stop',sessionId:id});
  const click=()=>{nav.userActivation.isActive=true;nodes.find(n=>n.textContent==='音声共有を選んで開始'&&!n.disabled).onclick();nav.userActivation.isActive=false;};
  return{context,events,nodes,recognitions,calls,intervals,timeouts,stream,audio,video,win,start,stop,click,command};
}
(async()=>{
  await test('Display request waits for explicit page click',async()=>{
    const h=harness();h.start();assert.equal(h.calls.length,0);assert.equal(h.events[0].kind,'waiting-user');
    h.click();assert.equal(h.calls[0].activated,true);await settle();
    assert.equal(h.recognitions[0].track,h.audio);assert.equal(h.calls[0].constraints.audio.suppressLocalAudioPlayback,false);
    assert.equal(h.video.stops,0);h.stop();assert.equal(h.video.stops,1);assert.equal(h.audio.stops,1);assert.equal(h.intervals.size,0);
  });
  await test('Tab capture uses original track and no screen prompt',async()=>{
    const h=harness();h.start('tab');await settle();assert.equal(h.calls[0].method,'tab');assert.equal(h.recognitions[0].track,h.audio);
    assert.equal(h.events.some(e=>e.kind==='waiting-user'),false);h.stop();
  });
  await test('Call acknowledgement differs from actual onstart',async()=>{
    const h=harness();h.start('tab');await settle();assert(h.events.some(e=>e.kind==='started'));
    assert(!h.events.some(e=>e.kind==='recognition-start'));h.recognitions[0].onstart();assert(h.events.some(e=>e.kind==='recognition-start'));h.stop();
  });
  await test('Interim and final transcripts are forwarded',async()=>{
    const h=harness();h.start('tab');await settle();const r=h.recognitions[0];
    const interim=Object.assign([{transcript:'途中'}],{isFinal:false});r.onresult({resultIndex:0,results:[interim]});
    const final=Object.assign([{transcript:'確定'}],{isFinal:true});r.onresult({resultIndex:0,results:[final]});
    assert(h.events.some(e=>e.kind==='interim'&&e.chars===2));assert.deepEqual(h.events.filter(e=>e.kind==='result').at(-1).finals,['確定']);h.stop();
  });
  await test('Source evidence survives missing bridge and stopping; no transcript retained',async()=>{
    const h=harness();h.start('tab');await settle();const r=h.recognitions[0];
    r.onresult({resultIndex:0,results:[Object.assign([{transcript:'秘密の途中'}],{isFinal:false})]});
    r.onresult({resultIndex:0,results:[Object.assign([{transcript:'秘密の確定'}],{isFinal:true})]});
    h.stop();const snapshot=h.win.__duoSpeechRcaSnapshot(),s=snapshot.sessions[0];
    assert.equal(s.resultEvents,2);assert.equal(s.finalResults,1);assert.equal(s.ackedFinalResults,0);
    assert.equal(s.events.find(e=>e.kind==='raw-final').resultSeq,2);
    assert(!JSON.stringify(snapshot).includes('秘密'));s.finalResults=99;
    assert.equal(h.win.__duoSpeechRcaSnapshot().sessions[0].finalResults,1);
  });
  await test('A and B differ only in audio constraint and both keep original track',async()=>{
    const a=harness(),b=harness();a.start();a.click();
    b.command({action:'start',captureMethod:'display',audioProfile:'html-audio',sessionId:'b'});b.click();await settle();
    const ca=JSON.parse(JSON.stringify(a.calls[0].constraints)),cb=JSON.parse(JSON.stringify(b.calls[0].constraints));
    assert.deepEqual(ca.audio,{suppressLocalAudioPlayback:false});assert.equal(cb.audio,true);
    delete ca.audio;delete cb.audio;assert.deepEqual(ca,cb);
    assert.equal(a.recognitions[0].track,a.audio);assert.equal(b.recognitions[0].track,b.audio);
    a.stop();b.stop('b');
  });
  for(const applied of [false,true,undefined])await test('C verifies actual echo cancellation setting: '+applied,async()=>{
    const b=harness(),c=harness({trackSettings:{echoCancellation:applied,noiseSuppression:true,autoGainControl:true}});
    b.command({action:'start',captureMethod:'display',audioProfile:'html-audio',sessionId:'b'});b.click();
    c.command({action:'start',captureMethod:'display',audioProfile:'no-echo',sessionId:'c'});c.click();await settle();
    const cb=JSON.parse(JSON.stringify(b.calls[0].constraints)),cc=JSON.parse(JSON.stringify(c.calls[0].constraints));
    assert.equal(cb.audio,true);assert.deepEqual(cc.audio,{echoCancellation:false});
    delete cb.audio;delete cc.audio;assert.deepEqual(cb,cc);
    const report=c.win.__duoSpeechRcaSnapshot().sessions[0].experiment;
    assert.equal(report.verified,applied===false);assert.equal(report.applied,applied??null);
    assert.equal(c.recognitions[0].track,c.audio);assert.equal(report.noiseSuppression,true);assert.equal(report.autoGainControl,true);
    assert(c.events.some(e=>e.kind==='audio-experiment'&&e.verified===(applied===false)));
    b.stop('b');c.stop('c');
  });
  await test('Final indexes correlate across resultIndex and recognition restarts',async()=>{
    const h=harness();h.start('tab');await settle();
    const f=Object.assign([{transcript:'一'}],{isFinal:true}),i=Object.assign([{transcript:'二'}],{isFinal:false});
    h.recognitions[0].onresult({resultIndex:1,results:[f,f,i]});
    let e=h.events.filter(e=>e.kind==='result').at(-1);assert.equal(e.trace.resultsMeta[0].index,1);assert.equal(e.trace.finalCount,1);
    h.command({action:'result-ack',sessionId:'one',resultSeq:1,finalCount:1});
    assert.equal(h.win.__duoSpeechRcaSnapshot().sessions[0].ackedFinalResults,1);
    h.recognitions[0].onend();h.timeouts.values().next().value();
    h.recognitions[1].onresult({resultIndex:0,results:[f]});
    e=h.events.filter(e=>e.kind==='result').at(-1);assert.equal(e.trace.generation,1);assert.equal(e.trace.resultSeq,2);h.stop();
  });
  await test('Source journal bounds history without losing aggregate counts',async()=>{
    const h=harness();h.start('tab');await settle();
    for(let n=0;n<180;n++)h.recognitions[0].onresult({resultIndex:0,results:[Object.assign([{transcript:'文'}],{isFinal:true})]});
    const s=h.win.__duoSpeechRcaSnapshot().sessions[0];assert.equal(s.finalResults,180);assert.equal(s.events.length,160);assert(s.evicted>0);h.stop();
  });
  await test('App distinguishes received, applied, noise and echo finals',async()=>{
    const app=fs.readFileSync(path.join(root,'app.js'),'utf8');
    const handler=app.slice(app.indexOf('TargetTabWebSpeechEngine.prototype.handleEvent='),app.indexOf('TargetTabWebSpeechEngine.prototype.fail='));
    const audit=app.slice(app.indexOf('var SPEECH_RCA_APP ='),app.indexOf('function diagText('));
    const c=vm.createContext({TargetTabWebSpeechEngine:function(){},CFG:{interimOn:true},dlog(){},
      hasSpeechContent:t=>t!=='noise',isEcho:t=>t==='echo',punctuateTranscript:t=>t,langOf:()=> 'ja',
      addEntry:()=>({}),render(){},speakSrcNow(){},translate(){},removeEntry(){}});
    vm.runInContext(audit+handler,c);
    const e=new c.TargetTabWebSpeechEngine();e.sessionId='one';e.seat='A';
    e.handleEvent({detail:{kind:'result',sessionId:'one',lang:'ja',finals:['ok','noise','echo',''],trace:{resultSeq:1,sourceAt:Date.now()}}});
    const s=c.SPEECH_RCA_APP[0];assert.equal(s.finalResults,4);assert.equal(s.applied,1);assert.equal(s.noise,1);assert.equal(s.echo,1);assert.equal(s.empty,1);
    e.handleEvent({detail:{kind:'result',sessionId:'old',finals:['ignored']}});assert.equal(s.finalResults,4);
    assert(c.speechRcaFindings({ok:false},[])[0].includes('判定保留'));
    assert(c.speechRcaFindings({ok:true,snapshot:{sessions:[{sessionId:'one',resultEvents:3,finalResults:0}]}},[{sessionId:'one',finalResults:0}])[0].includes('未発生'));
    assert(c.speechRcaFindings({ok:true,snapshot:{sessions:[{sessionId:'old',resultEvents:3,finalResults:1}]}},[])[0].includes('転送判定は保留'));
    assert(c.speechRcaFindings({ok:true,snapshot:{sessions:[{sessionId:'one',resultEvents:3,finalResults:0,audioProfile:'no-echo',experiment:{verified:false}}]}},[{sessionId:'one',finalResults:0}])[0].includes('因果判定は保留'));
    assert(c.speechRcaFindings({ok:true,snapshot:{sessions:[{sessionId:'one',resultEvents:3,finalResults:5}]}},c.SPEECH_RCA_APP)[0].includes('差があります'));
    assert(c.speechRcaFindings({ok:true,snapshot:{sessions:[{sessionId:'one',resultEvents:3,finalResults:4}]}},c.SPEECH_RCA_APP)[0].includes('件数は一致'));
  });
  await test('Content relay adds timestamps and acknowledges only a successful app response',async()=>{
    const content=fs.readFileSync(path.join(root,'content-overlay.js'),'utf8');
    const section=content.slice(content.indexOf('  function emitSpeech('),content.indexOf('  function clampGeometry('));
    for(const ok of [true,false]){
      const sent=[],commands=[];
      const c=vm.createContext({speechSessionId:'one',chrome:{runtime:{sendMessage:async m=>{sent.push(m);return{ok};}}},
        window:{addEventListener(){},dispatchEvent:e=>commands.push(JSON.parse(e.detail))},
        CustomEvent:class{constructor(type,opts){this.type=type;this.detail=opts.detail;}}});
      vm.runInContext(section,c);c.emitSpeech({kind:'result',sessionId:'one',trace:{resultSeq:5,finalCount:2},finals:['a','b']});await settle();
      assert(Number.isFinite(sent[0].event.contentAt));
      assert.equal(commands[0].action,ok?'result-ack':'stop');
      if(ok){assert.equal(commands[0].resultSeq,5);assert.equal(commands[0].finalCount,2);}
    }
  });
  await test('Diagnostic export retrieves source independently and completes once on timeout',async()=>{
    const app=fs.readFileSync(path.join(root,'app.js'),'utf8');
    const section=app.slice(app.indexOf('function withDiagText('),app.indexOf("$('dlDiag').onclick"));
    for(const mode of ['success','reject','timeout']){
      let resolve,timer;const out=[];
      const bridge={send:()=>mode==='reject'?Promise.reject(new Error('unavailable')):mode==='timeout'?new Promise(r=>resolve=r):Promise.resolve({ok:true,snapshot:{sessions:[]}})};
      const c=vm.createContext({window:{DuoExtension:bridge},DuoExtension:bridge,navigator:{},
        diagText:()=>JSON.stringify(c.SPEECH_RCA_SOURCE),setTimeout:fn=>{timer=fn;return 1;},clearTimeout(){}});
      vm.runInContext(section,c);c.withDiagText(t=>out.push(t));await settle();
      if(mode==='timeout'){timer();resolve({ok:true});await settle();}
      assert.equal(out.length,1);assert.equal(JSON.parse(out[0]).ok,mode==='success');
    }
  });
  await test('Detailed errors retry three times then release resources',async()=>{
    const h=harness();h.start('tab');await settle();
    for(let i=0;i<3;i++){
      const r=h.recognitions.at(-1);r.onerror({error:'network',message:'diagnostic detail'});
      if(i<2){r.onend();const [id,fn]=h.timeouts.entries().next().value;h.timeouts.delete(id);fn();}
    }
    assert.equal(h.events.filter(e=>e.kind==='error').length,3);
    assert.equal(h.events.find(e=>e.kind==='error').message,'diagnostic detail');assert(h.events.some(e=>e.kind==='fatal'));
    assert.equal(h.audio.stops,1);assert.equal(h.intervals.size,0);assert.equal(h.timeouts.size,0);
  });
  await test('Stopping while screen picker is pending prevents late recognition',async()=>{
    let resolve;const pending=new Promise(r=>resolve=r);const h=harness({pending});h.start();h.click();h.stop();resolve(h.stream);await settle();
    assert.equal(h.recognitions.length,0);assert.equal(h.audio.stops,1);assert.equal(h.video.stops,1);
  });
  await test('Picker cancellation emits failure and cleans up',async()=>{
    const h=harness({reject:true});h.start();h.click();await settle();assert(h.events.some(e=>e.kind==='fatal'&&e.error==='NotAllowedError'));assert.equal(h.intervals.size,0);
  });
  await test('Missing audio stops video and does not use microphone',async()=>{
    const h=harness({noAudio:true});h.start();h.click();await settle();assert.equal(h.recognitions.length,0);assert.equal(h.video.stops,1);assert(h.events.some(e=>e.error==='no-audio-track'));
  });
  await test('Old session stop cannot cancel a new session',async()=>{
    const h=harness();h.start('display','old');h.start('display','new');h.stop('old');
    assert.equal(h.events.filter(e=>e.kind==='stopped').length,1);h.stop('new');assert.equal(h.intervals.size,0);
  });
  await test('Source ended releases both audio and video',async()=>{
    const h=harness();h.start();h.click();await settle();h.video.listeners.ended();assert(h.events.some(e=>e.error==='capture-ended'));assert.equal(h.audio.stops,1);assert.equal(h.intervals.size,0);
  });
  await test('Page navigation releases capture',async()=>{
    const h=harness();h.start('tab');await settle();h.win.dispatchEvent({type:'pagehide'});assert.equal(h.audio.stops,1);assert.equal(h.intervals.size,0);
  });
  await test('RMS is measured and included in error diagnostics',async()=>{
    const h=harness();h.start('tab');await settle();for(const fn of h.intervals.values())fn();h.recognitions[0].onerror({error:'network'});
    const e=h.events.find(e=>e.kind==='error');assert(e.rmsPeak>.09&&e.rmsPeak<.11);assert.equal(e.sampleRate,96000);h.stop();
  });
  await test('Diagnostic log snapshots nested objects and tolerates circular data',async()=>{
    const app=fs.readFileSync(path.join(root,'app.js'),'utf8');const section=app.slice(app.indexOf('var DLOG ='),app.indexOf('/* APIキーらしき文字列'));
    const c=vm.createContext({});vm.runInContext(section,c);
    vm.runInContext('var s={source:{audio:true}};dlog("test","snapshot",s);s.source.audio=false;',c);
    assert.equal(c.DLOG[0].d.source.audio,true);
    vm.runInContext('var cycle={};cycle.self=cycle;dlog("test","cycle",cycle);',c);assert(c.DLOG[1].d.snapshotError);
  });
  for(const method of ['display','tab','stale','no-echo']) await test('Worker routing for '+method,async()=>{
    let listener;const calls=[];
    const state={targetTabId:7,appTabId:9};
    const chrome={
      storage:{session:{get:async()=>({duoChromeSession:state}),set:async()=>{}}},
      runtime:{onMessage:{addListener(fn){listener=fn;}}},
      scripting:{insertCSS:async()=>{},executeScript:async(args)=>{calls.push({kind:'inject',args});return[{result:'20260906-chrome103-rca-echo'}];}},
      tabs:{onRemoved:{addListener(){}},get:async()=>({id:7,url:'https://example.test/',windowId:2}),
        sendMessage:async(id,msg)=>{calls.push({kind:'message',id,msg});return{ok:true,htmlBridgeVersion:'1.2.4',speechBuild:method==='stale'?'old':'20260906-chrome103-rca-echo',result:{world:'main'}};},
        update:async(id,opts)=>calls.push({kind:'focus',id,opts})},
      windows:{update:async()=>{}},tabCapture:{getMediaStreamId:async(args)=>{calls.push({kind:'streamId',args});return'test-stream';}}
    };
    vm.runInNewContext(fs.readFileSync(path.join(root,'service-worker.js'),'utf8'),{chrome,importScripts(){}});
    const profile=method==='no-echo'?'no-echo':'html-audio';
    const result=await new Promise(resolve=>listener({type:'DUO_START_TARGET_WEB_SPEECH',captureMethod:method==='no-echo'?'display':method,audioProfile:profile,sessionId:'s',seat:'A',lang:'ja-JP'},{tab:{id:9}},resolve));
    if(method==='stale'){assert.equal(result.ok,false);assert(result.error.includes('旧版'));assert(!calls.some(c=>c.kind==='message'&&c.msg.type==='DUO_START_TARGET_WEB_SPEECH'));return;}
    assert.equal(result.ok,true);assert(calls.some(c=>c.kind==='inject'&&c.args.world==='MAIN'));
    assert.equal(calls.filter(c=>c.kind==='streamId').length,method==='tab'?1:0);
    const message=calls.find(c=>c.kind==='message'&&c.msg.type==='DUO_START_TARGET_WEB_SPEECH');
    assert.equal(message.msg.captureMethod,method==='no-echo'?'display':method);assert.equal(message.id,7);
    assert.equal(message.msg.audioProfile,profile);
    const snapshotResult=await new Promise(resolve=>listener({type:'DUO_GET_SPEECH_RCA'},{tab:{id:9}},resolve));
    assert.equal(snapshotResult.ok,true);assert(calls.some(c=>c.kind==='inject'&&c.args.func));
    const forbidden=await new Promise(resolve=>listener({type:'DUO_GET_SPEECH_RCA'},{tab:{id:88}},resolve));
    assert.equal(forbidden.ok,false);
    if(method==='tab')assert.equal(calls.find(c=>c.kind==='streamId').args.consumerTabId,7);
    else assert(calls.some(c=>c.kind==='focus'&&c.id===7));
  });
  console.log(JSON.stringify({ok:true,passed:tests.length,tests},null,2));
})().catch(error=>{console.error(error);process.exitCode=1;});
