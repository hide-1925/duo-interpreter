'use strict';
const fs=require('fs'),vm=require('vm'),assert=require('node:assert/strict'),path=require('path');
const code=fs.readFileSync(path.join(__dirname,'../popup.js'),'utf8');
const source=code.slice(code.indexOf("$('allowPlayerFrames').addEventListener"),code.indexOf('function validTarget'));
(async()=>{
 for(const granted of [true,false]){
  let click;const calls=[],origins=['https://tenant.sharepoint.com/*'];
  vm.runInNewContext(source,{$:()=>({addEventListener:(k,f)=>click=f}),missingPlayerOrigins:origins,
   chrome:{permissions:{request:async p=>{calls.push({type:'request',origins:[...p.origins]});return granted;}}},
   send:async m=>calls.push(m),refresh:async()=>calls.push({type:'refresh'}),show:(text,kind)=>calls.push({type:'status',kind})});
  const work=click();assert.equal(calls[0].type,'request');assert.deepEqual(calls[0].origins,origins);await work;
  assert.equal(calls.some(c=>c.type==='DUO_REFRESH_FRAMES'),granted);assert.equal(calls.at(-1).kind,granted?'ok':'err');
 }
 console.log('PASS: permission requested directly from click, exact discovered origins, denial does not connect frames');
})().catch(e=>{console.error(e);process.exitCode=1;});
