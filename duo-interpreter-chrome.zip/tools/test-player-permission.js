'use strict';
const fs=require('fs'),vm=require('vm'),assert=require('node:assert/strict'),path=require('path');
const code=fs.readFileSync(path.join(__dirname,'../popup.js'),'utf8');
const source=code.slice(code.indexOf("$('setTarget').addEventListener"),code.indexOf("$('openApp').addEventListener"));
(async()=>{
 for(const granted of [true,false]){
  let click;const calls=[],origins=['https://tenant.sharepoint.com/*'];
  const button={addEventListener:(k,f)=>click=f};
  vm.runInNewContext(source,{$:()=>button,targetPermissionOrigins:origins,registeredHtmlUrl:'https://duo.test/',URL,htmlUrlDirty:false,activeTab:{id:2},state:{htmlTabId:1},validTarget:()=>true,
   chrome:{permissions:{request:async p=>{calls.push({type:'request',origins:[...p.origins]});return granted;}}},
   send:async m=>{calls.push(m);return {state:{htmlTabId:1,htmlTabAudio:true}};},refresh:async()=>calls.push({type:'refresh'}),show:(text,kind)=>calls.push({type:'status',kind})});
  const work=click();assert.equal(calls[0].type,'request');assert.deepEqual(calls[0].origins,[...origins,'https://duo.test/*']);await work;
  assert.equal(calls.some(c=>c.type==='DUO_SET_TARGET'),granted);assert.equal(calls.at(-1).kind,granted?'ok':'err');
 }
 const html=fs.readFileSync(path.join(__dirname,'../popup.html'),'utf8');
 assert(!html.includes('id="allowPlayerFrames"'));assert(!html.includes('id="tabAudio"'));assert(!code.includes("$('tabAudio')"));
 console.log('PASS: combined target click requests prepared exact origins before async work, then connects; denial stops connection; redundant buttons removed');
})().catch(e=>{console.error(e);process.exitCode=1;});
